var num = 80;
var x = [];
var y = [];

function setup() {
    createCanvas(600, 600);

    noStroke();
    for (var i = 0; i < num; i++) {
        x[i] = 0;
        y[i] = 0;
    }
}
function draw() {
    background(50);
    for (var i = num - 1; i > 0; i--) {
        x[i] = x[i - 1];
        y[i] = y[i - 1];
    }
    y[0] = mouseY;
    x[0] = mouseX;
    for (var i = 0; i < num; i++) {
        fill(i * 5);

        rect(x[i], y[i], 80, 20);
    }
    print(y.length);
}
