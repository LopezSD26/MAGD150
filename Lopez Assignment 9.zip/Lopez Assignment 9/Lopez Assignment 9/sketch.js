//variables
var capture, sine, select;
var freq = 400;
var radius = 30;
var speed = 4.0;
var direction = 1;


function preload()
{
	//preload audio file
	select = loadSound("Select.wav");
}
function setup() {
	createCanvas(800, 800);
	// webcam capture
	capture = createCapture();
	capture.hide();
	ellipseMode(RADIUS);
	x = 300;
	sine = new p5.SinOsc();
	sine.start();
}
function draw() {
	//sine frequency soudn
	var hertz = map(mouseX, 0, 400, 20.0, 440.0);
	sine.freq(hertz);

	//pacman animation with sound applied
	background(200);
	x += speed * direction;
	if ((x < 100 + radius) || (x > 400 - radius)) {
		direction = -direction;

		//play audio
		select.play();
	}
	//pacman changes direction when distance is met
	if (direction == 1) {
		fill(0);
		arc(x, 400, radius, radius, 0.52, 5.76);
	} else {
		fill(0);
		arc(x, 400, radius, radius, 3.67, 8.9);
}	
	for (var z = 0; z < 400; z++) {
		var angle = map(z, 0, 400, 0, TWO_PI * hertz);
		var sinValue = sin(angle) * 120;
		stroke(50);
		line(z, -200, z, 200 + sinValue);		
	}
	// webcam
	var aspectRatio = capture.height / capture.width;
	var h = (width / 2) * aspectRatio;
	//webcam placement & filter
	image(capture, 400, 50, (width / 2), h);
	filter(INVERT);
}
