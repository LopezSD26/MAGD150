

var img;
var img2;
var img3;
function preload() {

	img = loadImage("Buddy.png");
	img2 = loadImage("cat.jpg")
	img3 = loadImage("water.png")
}

function setup() {

	createCanvas(800, 800);

}
function draw() {

	
	
	//3 images loaded. 2 using the mouse to move or resize image
	image(img2, 0, 0, mouseX * 2, mouseY * 2);
	image(img3, 0, mouseY * -1)
	image(img, 0, 0);

	//text
	fill(255);
	textSize(30);
	textFont('Georgia');
	stroke(255);
	text('Howdy yall welcome to this program', 180,400);
}